export default `flf2a$ 1 1 9 0 40 0 8256 0
#
# benjamin.flf  //  Version 02  //  2001-06-04
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
# This font is based on article <5m7lhtg5vj1esom25btrdugng0mseqisqv@4ax.com>
# from the newsgroup de.alt.rec.ascii-art and its follow-ups.
#
# The most current version of this font should be available here:
# http://www.cgarbs.de/stuff/benjamin.flf.gz
#
#-[WhoIsWho]------------------------------------------------------------------
# 
# Font creators:
# >> Benjamin Weiland <benjamin.weiland@uloc.de>
# >> Markus Gebhard <ukgh@rz.uni-karlsruhe.de>
# >> Christian Garbs <mitch@cgarbs.de>
#
# .flf file maintainer:
# Christian Garbs <mitch@cgarbs.de>
#
#-[History]-------------------------------------------------------------------
#
# 2001-06-04::Version 02
# * added the comments you're reading now
# * changed download location to www.cgarbs.de
# * added 0-9, &, German umlauts + ess-zed
# * changed X
#
# 2001-06-03::Version 01
# * available characters: A-Z, a-z, @, *
#
#-[Commercial]----------------------------------------------------------------
#
#                         _       __,"\\\\  _.      _    de.alt.rec.ascii-art
#      /\\\\     /\\\\   _.--/ \`.   ,' (   "_//"   __| |__ _ _ _ __ _ ___ __ _
#   ,''\\,"  ,""\\,"=='(   \\.'\\\\_,(  _\`-'=-'    / _\` / _\` | '_/ _\` |___/ _\` |
#  ' u-u \`=' u-u     |l''|l  \`" |m' |m  -bf-  \\__,_\\__,_|_| \\__,_|   \\__,_|
#
#-[TheEnd]--------------------------------------------------------------------
#
$@@
!@@
"@@
#@@
S@@
%@@
&@@
'@@
(@@
)@@
x@@
+@@
,@@
-@@
.@@
/@@
(\\)@@
'|@@
^/_@@
-}@@
+|@@
;"@@
(o@@
"/@@
{}@@
")@@
:@@
;@@
<@@
=@@
>@@
?@@
(a)@@
/-\\@@
|3@@
(@@
|)@@
[-@@
|=@@
[,@@
|-|@@
|@@
.]@@
|<@@
|_@@
|\\/|@@
|\\|@@
()@@
|'@@
()_@@
|2@@
_\\"@@
"|"@@
|_|@@
\\/@@
\\/\\/@@
><@@
\`/@@
"/_@@
[@@
\\@@
]@@
^@@
_@@
\`@@
/-\\@@
|3@@
(@@
|)@@
[-@@
|=@@
[,@@
|-|@@
|@@
.]@@
|<@@
|_@@
|\\/|@@
|\\|@@
()@@
|'@@
()_@@
|2@@
_\\"@@
"|"@@
|_|@@
\\/@@
\\/\\/@@
\`/.@@
\`/@@
"/_@@
{@@
|@@
}@@
~@@
'/-\\'@@
'()'@@
'|_|'@@
'/-\\'@@
'()'@@
i_i@@
/3@@
`