export default `flf2a$ 2 1 8 -1 13

                  1row font by unknown
                 =======================


-> Conversion to FigLet font by MEPH. (Part of ASCII Editor Service Pack I)
   (http://studenten.freepage.de/meph/ascii/editor/_index.htm)
-> Defined: ASCII code alphanumeric
-> Uppercase characters only.


Was a part of a '1row' font collection. Author unknown.

 $@
 $@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
(\\) @
    @@
'| @
   @@
^/_ @
    @@
-} @
   @@
+| @
   @@
;~ @
   @@
(o @
   @@
"/ @
   @@
{} @
   @@
"| @
   @@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
/\\ @
   @@
]3 @
   @@
( @
  @@
|) @
   @@
[- @
   @@
/= @
   @@
(_, @
    @@
|-| @
    @@
| @
  @@
_T @
   @@
/< @
   @@
|_ @
   @@
|\\/| @
     @@
|\\| @
    @@
() @
   @@
|^ @
   @@
()_ @
    @@
/? @
   @@
_\\~ @
    @@
~|~ @
    @@
|_| @
    @@
\\/ @
   @@
\\/\\/ @
     @@
>< @
   @@
\`/ @
   @@
~/_ @
    @@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
/\\ @
   @@
]3 @
   @@
( @
  @@
|) @
   @@
[- @
   @@
/= @
   @@
(_, @
    @@
|-| @
    @@
| @
  @@
_T @
   @@
/< @
   @@
|_ @
   @@
|\\/| @
     @@
|\\| @
    @@
() @
   @@
|^ @
   @@
()_ @
    @@
/? @
   @@
_\\~ @
    @@
~|~ @
    @@
|_| @
    @@
\\/ @
   @@
\\/\\/ @
     @@
>< @
   @@
\`/ @
   @@
~/_ @
    @@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
@
@@
`