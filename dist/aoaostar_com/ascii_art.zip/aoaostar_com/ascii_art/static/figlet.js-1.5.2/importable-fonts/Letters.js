export default `flf2a$ 6 5 20 15 11
Letters by Sriram J. Gollapalli,  July 10, 1994

  o__         +----------------------+          __o
 _.>/)_       | Sriram J. Gollapalli |        _(\\<._
(_) \\(_)      +----------------------+       (_)/ (_)  
               <sriram@capaccess.org>

---

Font modified June 17, 2007 (without permission) by patorjk 
This was to widen "space" character.
$ $@
$ $@
$ $@
$ $@
$ $@
$ $@@
!!!$@
!!!$@
!!!$@
   $@
!!!$@
   $@@
"""""$@
"""""$@
 """ $@
     $@
     $@
     $@@
        $@
  ## ## $@
 #######$@
 #######$@
  ## ## $@
        $@@
 /|-\\$@
/ |  $@
\\-|-\\$@
  | |$@
\\-|-/$@
     $@@
%%  %%$@
%% %% $@
  %%  $@
 %% %%$@
%%  %%$@
      $@@
  &&&   $@
 && &&  $@
 &&&&&&&$@
&&& &&  $@
 &&&&&&&$@
        $@@
 ' $@
'''$@
'' $@
   $@
   $@
   $@@
    $@
 ((($@
((( $@
((( $@
((( $@
 ((($@@
    $@
))) $@
 )))$@
 )))$@
 )))$@
))) $@@
     $@
*   *$@
 *** $@
 *** $@
*   *$@
     $@@
       $@
  +++  $@
+++++++$@
+++++++$@
  +++  $@
       $@@
   $@
   $@
   $@
 , $@
,,,$@
,, $@@
       $@
       $@
 _____ $@
       $@
       $@
       $@@
   $@
   $@
   $@
...$@
...$@
   $@@
    //$@
   ///$@
  /// $@
 ///  $@
///   $@
      $@@
 00000 $@
00   00$@
00   00$@
00   00$@
 00000 $@
       $@@
 1 $@
111$@
 11$@
 11$@
111$@
   $@@
 2222  $@
222222 $@
    222$@
 2222  $@
2222222$@
       $@@
333333 $@
   3333$@
  3333 $@
    333$@
333333 $@
       $@@
    44  $@
   444  $@
 44  4  $@
44444444$@
   444  $@
        $@@
555555 $@
55     $@
555555 $@
   5555$@
555555 $@
       $@@
  666  $@
 66    $@
666666 $@
66   66$@
 66666 $@
       $@@
7777777$@
    777$@
   777 $@
  777  $@
 777   $@
       $@@
 88888 $@
88   88$@
 88888 $@
88   88$@
 88888 $@
       $@@
       $@
 99999 $@
99   99$@
 999999$@
    99 $@
  999  $@@
   $@
   $@
:::$@
   $@
:::$@
   $@@
   $@
   $@
;;;$@
   $@
;;;$@
;; $@@
    $@
 <<<$@
<<< $@
<<< $@
 <<<$@
    $@@
       $@
       $@
=======$@
=======$@
       $@
       $@@
    $@
>>> $@
 >>>$@
 >>>$@
>>> $@
    $@@
 ??? $@
?? ??$@
   ??$@
  ?? $@
  ?? $@
     $@@
  @@@@ $@
 @ @@ @$@
@ @  @@$@
@  @@@ $@
 @@@@@ $@
       $@@
  AAA  $@
 AAAAA $@
AA   AA$@
AAAAAAA$@
AA   AA$@
       $@@
BBBBB  $@
BB   B $@
BBBBBB $@
BB   BB$@
BBBBBB $@
       $@@
 CCCCC $@
CC    C$@
CC     $@
CC    C$@
 CCCCC $@
       $@@
DDDDD  $@
DD  DD $@
DD   DD$@
DD   DD$@
DDDDDD $@
       $@@
EEEEEEE$@
EE     $@
EEEEE  $@
EE     $@
EEEEEEE$@
       $@@
FFFFFFF$@
FF     $@
FFFF   $@
FF     $@
FF     $@
       $@@
  GGGG $@
 GG  GG$@
GG     $@
GG   GG$@
 GGGGGG$@
       $@@
HH   HH$@
HH   HH$@
HHHHHHH$@
HH   HH$@
HH   HH$@
       $@@
IIIII$@
 III $@
 III $@
 III $@
IIIII$@
     $@@
    JJJ$@
    JJJ$@
    JJJ$@
JJ  JJJ$@
 JJJJJ $@
       $@@
KK  KK$@
KK KK $@
KKKK  $@
KK KK $@
KK  KK$@
      $@@
LL     $@
LL     $@
LL     $@
LL     $@
LLLLLLL$@
       $@@
MM    MM$@
MMM  MMM$@
MM MM MM$@
MM    MM$@
MM    MM$@
        $@@
NN   NN$@
NNN  NN$@
NN N NN$@
NN  NNN$@
NN   NN$@
       $@@
 OOOOO $@
OO   OO$@
OO   OO$@
OO   OO$@
 OOOO0 $@
       $@@
PPPPPP $@
PP   PP$@
PPPPPP $@
PP     $@
PP     $@
       $@@
 QQQQQ $@
QQ   QQ$@
QQ   QQ$@
QQ  QQ $@
 QQQQ Q$@
       $@@
RRRRRR $@
RR   RR$@
RRRRRR $@
RR  RR $@
RR   RR$@
       $@@
 SSSSS $@
SS     $@
 SSSSS $@
     SS$@
 SSSSS $@
       $@@
TTTTTTT$@
  TTT  $@
  TTT  $@
  TTT  $@
  TTT  $@
       $@@
UU   UU$@
UU   UU$@
UU   UU$@
UU   UU$@
 UUUUU $@
       $@@
VV     VV$@
VV     VV$@
 VV   VV $@
  VV VV  $@
   VVV   $@
         $@@
WW      WW$@
WW      WW$@
WW   W  WW$@
 WW WWW WW$@
  WW   WW $@
          $@@
XX    XX$@
 XX  XX $@
  XXXX  $@
 XX  XX $@
XX    XX$@
        $@@
YY   YY$@
YY   YY$@
 YYYYY $@
  YYY  $@
  YYY  $@
       $@@
ZZZZZ$@
   ZZ$@
  ZZ $@
 ZZ  $@
ZZZZZ$@
     $@@
[[[[$@
[[  $@
[[  $@
[[  $@
[[[[$@
    $@@
\\\\    $@
 \\\\   $@
  \\\\  $@
   \\\\ $@
    \\\\$@
      $@@
]]]]$@
  ]]$@
  ]]$@
  ]]$@
]]]]$@
    $@@
 ^^ $@
^^^^$@
^  ^$@
    $@
    $@
    $@@
       $@
       $@
       $@
       $@
_______$@
       $@@
 \` $@
\`\`\`$@
 \`\`$@
   $@
   $@
   $@@
       $@
  aa aa$@
 aa aaa$@
aa  aaa$@
 aaa aa$@
       $@@
bb     $@
bb     $@
bbbbbb $@
bb   bb$@
bbbbbb $@
       $@@
      $@
  cccc$@
cc    $@
cc    $@
 ccccc$@
      $@@
     dd$@
     dd$@
 dddddd$@
dd   dd$@
 dddddd$@
       $@@
      $@
  eee $@
ee   e$@
eeeee $@
 eeeee$@
      $@@
 fff$@
ff  $@
ffff$@
ff  $@
ff  $@
    $@@
       $@
 gggggg$@
gg   gg$@
ggggggg$@
     gg$@
 ggggg $@@
hh     $@
hh     $@
hhhhhh $@
hh   hh$@
hh   hh$@
       $@@
iii$@
   $@
iii$@
iii$@
iii$@
   $@@
  jjj$@
     $@
  jjj$@
  jjj$@
  jjj$@
jjjj $@@
kk    $@
kk  kk$@
kkkkk $@
kk kk $@
kk  kk$@
      $@@
lll$@
lll$@
lll$@
lll$@
lll$@
   $@@
           $@
mm mm mmmm $@
mmm  mm  mm$@
mmm  mm  mm$@
mmm  mm  mm$@
           $@@
       $@
nn nnn $@
nnn  nn$@
nn   nn$@
nn   nn$@
       $@@
      $@
 oooo $@
oo  oo$@
oo  oo$@
 oooo $@
      $@@
       $@
pp pp  $@
ppp  pp$@
pppppp $@
pp     $@
pp     $@@
       $@
  qqqqq$@
qq   qq$@
 qqqqqq$@
     qq$@
     qq$@@
      $@
rr rr $@
rrr  r$@
rr    $@
rr    $@
      $@@
     $@
 sss $@
s    $@
 sss $@
    s$@
 sss $@@
tt   $@
tt   $@
tttt $@
tt   $@
 tttt$@
     $@@
       $@
uu   uu$@
uu   uu$@
uu   uu$@
 uuuu u$@
       $@@
       $@
vv   vv$@
 vv vv $@
  vvv  $@
   v   $@
       $@@
          $@
ww      ww$@
ww      ww$@
 ww ww ww $@
  ww  ww  $@
          $@@
      $@
xx  xx$@
  xx  $@
  xx  $@
xx  xx$@
      $@@
       $@
yy   yy$@
yy   yy$@
 yyyyyy$@
     yy$@
 yyyyy $@@
     $@
zzzzz$@
  zz $@
 zz  $@
zzzzz$@
     $@@
   {{$@
  {{ $@
{{{  $@
{{{  $@
  {{ $@
   {{$@@
  $@
||$@
||$@
||$@
||$@
||$@@
}}   $@
 }}  $@
  }}}$@
  }}}$@
 }}  $@
}}   $@@
      $@
 ~~ ~~$@
~  ~  $@
      $@
      $@
      $@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
@
@
@
@
@
@@
`