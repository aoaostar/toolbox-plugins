export default `flf2a$ 4 4 17 -1 48 0 0 0
Author : LG Beard
Date   : 2003/9/10 10:37:00
Version: 1.3
-------------------------------------------------

-------------------------------------------------
This font has been created using JavE's FIGlet font export assistant.
Have a look at: http://www.jave.de

Permission is hereby given to modify this font, as long as the
modifier's name is placed on a comment line.

Ran upon a few sig\`s created by sanne jabs awhile ago. Five sig\`s
all that were found. One articile stating that there was a hieroglyphic
font, never found it. From those an some reading about how to use an
write with hieroglyphs this file came about. Hopefully these are read-
able, tried to keep them as close as possible to the real thing. If 
they are not then i blew it real bad.

Thanks sanne for the spark.

Some upper case keys used for some alt symbols

C = ch
G = fancy jar
H = alt h
M = alt m
P = fancy door
T = alt T
X = sh
Y = alt y

The symbol below stands for writing or scribe to my understanding
2 ink spots on pallette, a jar for ink or water, his writing implement,
and a string or rope that is slung over the shoulder to carry the 
tools of the trade.

  ,-~.
  |   \\ \\|/
 _|_  |=-|)
| o |(_) |
|_o_|    |

This file is simply just for fun, write your name, wrap in a cartouche.
 _____ .
(_____)| a tiny one
       '
but most of all, enjoy.
$ #
$ #
$ #
$ ##
!#
 #
 #
 ##
"#
 #
 #
 ##
##
 #
 #
 ##
$#
 #
 #
 ##
%#
 #
 #
 ##
&#
 #
 #
 ##
'#
 #
 #
 ##
(#
 #
 #
 ##
)#
 #
 #
 ##
*#
 #
 #
 ##
+#
 #
 #
 ##
,#
 #
 #
 ##
-#
 #
 #
 ##
.#
 #
 #
 ##
/#
 #
 #
 ##
0#
 #
 #
 ##
1#
 #
 #
 ##
2#
 #
 #
 ##
3#
 #
 #
 ##
4#
 #
 #
 ##
5#
 #
 #
 ##
6#
 #
 #
 ##
7#
 #
 #
 ##
8#
 #
 #
 ##
9#
 #
 #
 ##
:#
 #
 #
 ##
;#
 #
 #
 ##
<#
 #
 #
 ##
=#
 #
 #
 ##
>#
 #
 #
 ##
?#
 #
 #
 ##
@#
 #
 #
 ##
,-~~\\    #
 (   \\   #
  |\\. \\  #
 _]_]\`\\\\ ##
   || #
   || #
   || #
.-'_| ##
 .-===-., #
 \`.___.'  #
 _______  #
|_______| ##
     _       #
 __,(: \`,_,. #
(.-_-   __ | #
  \`----'  -' ##
            #
         || #
....     || #
\`=.\`''===.' ##
          #
 \\/       #
\`-'_      #
    \`---. ##
 ______  #
'-.--.-' #
 /::::\\  #
 )_/\\_(  ##
() #
() #
() #
/\\ ##
 ;. #
; | #
\`.| #
  | ##
  _   #
 \`-)  #
 _/,' #
(___) ##
         #
         #
.-===-., #
\`.___.'  ##
  ,-.       ,-.#
 <,- \\_____/  \`#
   /  ___. \\   #
,_(__/ ,_(__\\  ##
       #
       #
 _____ #
/_____ ##
        #
        #
        #
^^^^^^^ ##
      #
 .-.  #
_|_ \\ #
(_)   ##
|||[]||| #
|_|[]|_| #
|=|[]|=| #
|||[]||| ##
     #
     #
 .'| #
/__| ##
        #
        #
 .---.  #
'.___.' ##
,-. #
| | #
| ' #
|   ##
        #
        #
()----. #
()----' ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
.''.  #
'.' ) #
   /  #
 .'   ##
           #
 ...       #
(   X-==== #
 '''       ##
 ;.  ;. #
; | ; | #
\`.| \`.| #
  |   | ##
          #
          #
          #
---<|>--- ##
[#
 #
 #
 ##
\\#
 #
 #
 ##
]#
 #
 #
 ##
^#
 #
 #
 ##
_#
 #
 #
 ##
\`#
 #
 #
 ##
,-~~\\    #
 (   \\   #
  |\\. \\  #
 _]_]\`\\\\ ##
   || #
   || #
   || #
.-'_| ##
         #
         #
.-===-., #
\`.___.'  ##
     _       #
 __,(: \`,_,. #
(.-_-   __ | #
  \`----'  -' ##
            #
         || #
....     || #
\`=.\`''===.' ##
          #
 \\/       #
\`-'_      #
    \`---. ##
       #
 ____  #
 /  \\  #
/_/\\_\\ ##
      #
 ___  #
|   | #
| |_| ##
 ;. #
; | #
\`.| #
  | ##
  _   #
 \`-)  #
 _/,' #
(___) ##
         #
         #
.-===-., #
\`.___.'  ##
  ,-.       ,-.#
 <,- \\_____/  \`#
   /  ___. \\   #
,_(__/ ,_(__\\  ##
,-==.    #
 (  (\\   #
  |\\.\\\\  #
 _]_]\`\\\\ ##
        #
        #
        #
^^^^^^^ ##
      #
 .-.  #
_|_ \\ #
(_)   ##
     #
     #
 __  #
|__| ##
     #
     #
 .'| #
/__| ##
        #
        #
 .---.  #
'.___.' ##
,-. #
| | #
| ' #
|   ##
         #
         #
 .-==-.  #
/______\\ ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
.''.  #
'.' ) #
   /  #
 .'   ##
 .-===-., #
 \`.___.'  #
          #
---<|>--- ##
\\\\ \\\\    #
 \\\\ \\\\   #
  \\\\ \\\\  #
   \\\\ \\\\ ##
          #
          #
          #
---<|>--- ##
{#
 #
 #
 ##
|#
 #
 #
 ##
}#
 #
 #
 ##
~#
 #
 #
 ##
,-~~\\    #
 (   \\   #
  |\\. \\  #
 _]_]\`\\\\ ##
      #
 .-.  #
_|_ \\ #
(_)   ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
,-~~\\    #
 (   \\   #
  |\\. \\  #
 _]_]\`\\\\ ##
      #
 .-.  #
_|_ \\ #
(_)   ##
<~)_   #
 ( v~\\ #
  \\_/' #
  /\\   ##
�#
 #
 #
 ##`