export default `flf2a 4 3 8 15 11 0 10127 242
Bubble by Glenn Chappell 4/93
Includes characters 128-255
Enhanced for Latin-2,3,4 by John Cowan <cowan@ccil.org>
Latin character sets supported only if your screen font does
figlet release 2.2 -- November 1996
Permission is hereby given to modify this font, as long as the
modifier's name is placed on a comment line.

Modified by Paul Burton <solution@earthlink.net> 12/96 to include new parameter
supported by FIGlet and FIGWin.  May also be slightly modified for better use
of new full-width/kern/smush alternatives, but default output is NOT changed.
 @
 @
 @
 @@
   _  @
  / \\ @
 ( ! )@
  \\_/ @@
   _  @
  / \\ @
 ( " )@
  \\_/ @@
   _  @
  / \\ @
 ( # )@
  \\_/ @@
   _  @
  / \\ @
 ( $ )@
  \\_/ @@
   _  @
  / \\ @
 ( % )@
  \\_/ @@
   _  @
  / \\ @
 ( & )@
  \\_/ @@
   _  @
  / \\ @
 ( ' )@
  \\_/ @@
   _  @
  / \\ @
 ( ( )@
  \\_/ @@
   _  @
  / \\ @
 ( ) )@
  \\_/ @@
   _  @
  / \\ @
 ( * )@
  \\_/ @@
   _  @
  / \\ @
 ( + )@
  \\_/ @@
   _  @
  / \\ @
 ( , )@
  \\_/ @@
   _  @
  / \\ @
 ( - )@
  \\_/ @@
   _  @
  / \\ @
 ( . )@
  \\_/ @@
   _  @
  / \\ @
 ( / )@
  \\_/ @@
   _  @
  / \\ @
 ( 0 )@
  \\_/ @@
   _  @
  / \\ @
 ( 1 )@
  \\_/ @@
   _  @
  / \\ @
 ( 2 )@
  \\_/ @@
   _  @
  / \\ @
 ( 3 )@
  \\_/ @@
   _  @
  / \\ @
 ( 4 )@
  \\_/ @@
   _  @
  / \\ @
 ( 5 )@
  \\_/ @@
   _  @
  / \\ @
 ( 6 )@
  \\_/ @@
   _  @
  / \\ @
 ( 7 )@
  \\_/ @@
   _  @
  / \\ @
 ( 8 )@
  \\_/ @@
   _  @
  / \\ @
 ( 9 )@
  \\_/ @@
   _  @
  / \\ @
 ( : )@
  \\_/ @@
   _  @
  / \\ @
 ( ; )@
  \\_/ @@
   _  @
  / \\ @
 ( < )@
  \\_/ @@
   _  @
  / \\ @
 ( = )@
  \\_/ @@
   _  @
  / \\ @
 ( > )@
  \\_/ @@
   _  @
  / \\ @
 ( ? )@
  \\_/ @@
   _  @
  / \\ @
 ( @ )@
  \\_/ @@
   _  @
  / \\ @
 ( A )@
  \\_/ @@
   _  @
  / \\ @
 ( B )@
  \\_/ @@
   _  @
  / \\ @
 ( C )@
  \\_/ @@
   _  @
  / \\ @
 ( D )@
  \\_/ @@
   _  @
  / \\ @
 ( E )@
  \\_/ @@
   _  @
  / \\ @
 ( F )@
  \\_/ @@
   _  @
  / \\ @
 ( G )@
  \\_/ @@
   _  @
  / \\ @
 ( H )@
  \\_/ @@
   _  @
  / \\ @
 ( I )@
  \\_/ @@
   _  @
  / \\ @
 ( J )@
  \\_/ @@
   _  @
  / \\ @
 ( K )@
  \\_/ @@
   _  @
  / \\ @
 ( L )@
  \\_/ @@
   _  @
  / \\ @
 ( M )@
  \\_/ @@
   _  @
  / \\ @
 ( N )@
  \\_/ @@
   _  @
  / \\ @
 ( O )@
  \\_/ @@
   _  @
  / \\ @
 ( P )@
  \\_/ @@
   _  @
  / \\ @
 ( Q )@
  \\_/ @@
   _  @
  / \\ @
 ( R )@
  \\_/ @@
   _  @
  / \\ @
 ( S )@
  \\_/ @@
   _  @
  / \\ @
 ( T )@
  \\_/ @@
   _  @
  / \\ @
 ( U )@
  \\_/ @@
   _  @
  / \\ @
 ( V )@
  \\_/ @@
   _  @
  / \\ @
 ( W )@
  \\_/ @@
   _  @
  / \\ @
 ( X )@
  \\_/ @@
   _  @
  / \\ @
 ( Y )@
  \\_/ @@
   _  @
  / \\ @
 ( Z )@
  \\_/ @@
   _  @
  / \\ @
 ( [ )@
  \\_/ @@
   _  @
  / \\ @
 ( \\ )@
  \\_/ @@
   _  @
  / \\ @
 ( ] )@
  \\_/ @@
   _  @
  / \\ @
 ( ^ )@
  \\_/ @@
   _  @
  / \\ @
 ( _ )@
  \\_/ @@
   _  @
  / \\ @
 ( \` )@
  \\_/ @@
   _  @
  / \\ @
 ( a )@
  \\_/ @@
   _  @
  / \\ @
 ( b )@
  \\_/ @@
   _  @
  / \\ @
 ( c )@
  \\_/ @@
   _  @
  / \\ @
 ( d )@
  \\_/ @@
   _  @
  / \\ @
 ( e )@
  \\_/ @@
   _  @
  / \\ @
 ( f )@
  \\_/ @@
   _  @
  / \\ @
 ( g )@
  \\_/ @@
   _  @
  / \\ @
 ( h )@
  \\_/ @@
   _  @
  / \\ @
 ( i )@
  \\_/ @@
   _  @
  / \\ @
 ( j )@
  \\_/ @@
   _  @
  / \\ @
 ( k )@
  \\_/ @@
   _  @
  / \\ @
 ( l )@
  \\_/ @@
   _  @
  / \\ @
 ( m )@
  \\_/ @@
   _  @
  / \\ @
 ( n )@
  \\_/ @@
   _  @
  / \\ @
 ( o )@
  \\_/ @@
   _  @
  / \\ @
 ( p )@
  \\_/ @@
   _  @
  / \\ @
 ( q )@
  \\_/ @@
   _  @
  / \\ @
 ( r )@
  \\_/ @@
   _  @
  / \\ @
 ( s )@
  \\_/ @@
   _  @
  / \\ @
 ( t )@
  \\_/ @@
   _  @
  / \\ @
 ( u )@
  \\_/ @@
   _  @
  / \\ @
 ( v )@
  \\_/ @@
   _  @
  / \\ @
 ( w )@
  \\_/ @@
   _  @
  / \\ @
 ( x )@
  \\_/ @@
   _  @
  / \\ @
 ( y )@
  \\_/ @@
   _  @
  / \\ @
 ( z )@
  \\_/ @@
   _  @
  / \\ @
 ( { )@
  \\_/ @@
   _  @
  / \\ @
 ( | )@
  \\_/ @@
   _  @
  / \\ @
 ( } )@
  \\_/ @@
   _  @
  / \\ @
 ( ~ )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
   _  @
  / \\ @
 ( � )@
  \\_/ @@
128
   _  @
  / \\ @
 ( � )@
  \\_/ @@
129
   _  @
  / \\ @
 ( � )@
  \\_/ @@
130
   _  @
  / \\ @
 ( � )@
  \\_/ @@
131
   _  @
  / \\ @
 ( � )@
  \\_/ @@
132
   _  @
  / \\ @
 ( � )@
  \\_/ @@
133
   _  @
  / \\ @
 ( � )@
  \\_/ @@
134
   _  @
  / \\ @
 ( � )@
  \\_/ @@
135
   _  @
  / \\ @
 ( � )@
  \\_/ @@
136
   _  @
  / \\ @
 ( � )@
  \\_/ @@
137
   _  @
  / \\ @
 ( � )@
  \\_/ @@
138
   _  @
  / \\ @
 ( � )@
  \\_/ @@
139
   _  @
  / \\ @
 ( � )@
  \\_/ @@
140
   _  @
  / \\ @
 ( � )@
  \\_/ @@
141
   _  @
  / \\ @
 ( � )@
  \\_/ @@
142
   _  @
  / \\ @
 ( � )@
  \\_/ @@
143
   _  @
  / \\ @
 ( � )@
  \\_/ @@
144
   _  @
  / \\ @
 ( � )@
  \\_/ @@
145
   _  @
  / \\ @
 ( � )@
  \\_/ @@
146
   _  @
  / \\ @
 ( � )@
  \\_/ @@
147
   _  @
  / \\ @
 ( � )@
  \\_/ @@
148
   _  @
  / \\ @
 ( � )@
  \\_/ @@
149
   _  @
  / \\ @
 ( � )@
  \\_/ @@
150
   _  @
  / \\ @
 ( � )@
  \\_/ @@
151
   _  @
  / \\ @
 ( � )@
  \\_/ @@
152
   _  @
  / \\ @
 ( � )@
  \\_/ @@
153
   _  @
  / \\ @
 ( � )@
  \\_/ @@
154
   _  @
  / \\ @
 ( � )@
  \\_/ @@
155
   _  @
  / \\ @
 ( � )@
  \\_/ @@
156
   _  @
  / \\ @
 ( � )@
  \\_/ @@
157
   _  @
  / \\ @
 ( � )@
  \\_/ @@
158
   _  @
  / \\ @
 ( � )@
  \\_/ @@
159
   _  @
  / \\ @
 ( � )@
  \\_/ @@
160  NO-BREAK SPACE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
161  INVERTED EXCLAMATION MARK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
162  CENT SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
163  POUND SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
164  CURRENCY SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
165  YEN SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
166  BROKEN BAR
   _  @
  / \\ @
 ( � )@
  \\_/ @@
167  SECTION SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
168  DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
169  COPYRIGHT SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
170  FEMININE ORDINAL INDICATOR
   _  @
  / \\ @
 ( � )@
  \\_/ @@
171  LEFT-POINTING DOUBLE ANGLE QUOTATION MARK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
172  NOT SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
173  SOFT HYPHEN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
174  REGISTERED SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
175  MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
176  DEGREE SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
177  PLUS-MINUS SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
178  SUPERSCRIPT TWO
   _  @
  / \\ @
 ( � )@
  \\_/ @@
179  SUPERSCRIPT THREE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
180  ACUTE ACCENT
   _  @
  / \\ @
 ( � )@
  \\_/ @@
181  MICRO SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
182  PILCROW SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
183  MIDDLE DOT
   _  @
  / \\ @
 ( � )@
  \\_/ @@
184  CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
185  SUPERSCRIPT ONE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
186  MASCULINE ORDINAL INDICATOR
   _  @
  / \\ @
 ( � )@
  \\_/ @@
187  RIGHT-POINTING DOUBLE ANGLE QUOTATION MARK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
188  VULGAR FRACTION ONE QUARTER
   _  @
  / \\ @
 ( � )@
  \\_/ @@
189  VULGAR FRACTION ONE HALF
   _  @
  / \\ @
 ( � )@
  \\_/ @@
190  VULGAR FRACTION THREE QUARTERS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
191  INVERTED QUESTION MARK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
192  LATIN CAPITAL LETTER A WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
193  LATIN CAPITAL LETTER A WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
194  LATIN CAPITAL LETTER A WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
195  LATIN CAPITAL LETTER A WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
196  LATIN CAPITAL LETTER A WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
197  LATIN CAPITAL LETTER A WITH RING ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
198  LATIN CAPITAL LETTER AE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
199  LATIN CAPITAL LETTER C WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
200  LATIN CAPITAL LETTER E WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
201  LATIN CAPITAL LETTER E WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
202  LATIN CAPITAL LETTER E WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
203  LATIN CAPITAL LETTER E WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
204  LATIN CAPITAL LETTER I WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
205  LATIN CAPITAL LETTER I WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
206  LATIN CAPITAL LETTER I WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
207  LATIN CAPITAL LETTER I WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
208  LATIN CAPITAL LETTER ETH
   _  @
  / \\ @
 ( � )@
  \\_/ @@
209  LATIN CAPITAL LETTER N WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
210  LATIN CAPITAL LETTER O WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
211  LATIN CAPITAL LETTER O WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
212  LATIN CAPITAL LETTER O WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
213  LATIN CAPITAL LETTER O WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
214  LATIN CAPITAL LETTER O WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
215  MULTIPLICATION SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
216  LATIN CAPITAL LETTER O WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
217  LATIN CAPITAL LETTER U WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
218  LATIN CAPITAL LETTER U WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
219  LATIN CAPITAL LETTER U WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
220  LATIN CAPITAL LETTER U WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
221  LATIN CAPITAL LETTER Y WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
222  LATIN CAPITAL LETTER THORN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
223  LATIN SMALL LETTER SHARP S
   _  @
  / \\ @
 ( � )@
  \\_/ @@
224  LATIN SMALL LETTER A WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
225  LATIN SMALL LETTER A WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
226  LATIN SMALL LETTER A WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
227  LATIN SMALL LETTER A WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
228  LATIN SMALL LETTER A WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
229  LATIN SMALL LETTER A WITH RING ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
230  LATIN SMALL LETTER AE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
231  LATIN SMALL LETTER C WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
232  LATIN SMALL LETTER E WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
233  LATIN SMALL LETTER E WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
234  LATIN SMALL LETTER E WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
235  LATIN SMALL LETTER E WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
236  LATIN SMALL LETTER I WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
237  LATIN SMALL LETTER I WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
238  LATIN SMALL LETTER I WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
239  LATIN SMALL LETTER I WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
240  LATIN SMALL LETTER ETH
   _  @
  / \\ @
 ( � )@
  \\_/ @@
241  LATIN SMALL LETTER N WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
242  LATIN SMALL LETTER O WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
243  LATIN SMALL LETTER O WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
244  LATIN SMALL LETTER O WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
245  LATIN SMALL LETTER O WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
246  LATIN SMALL LETTER O WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
247  DIVISION SIGN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
248  LATIN SMALL LETTER O WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
249  LATIN SMALL LETTER U WITH GRAVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
250  LATIN SMALL LETTER U WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
251  LATIN SMALL LETTER U WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
252  LATIN SMALL LETTER U WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
253  LATIN SMALL LETTER Y WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
254  LATIN SMALL LETTER THORN
   _  @
  / \\ @
 ( � )@
  \\_/ @@
255  LATIN SMALL LETTER Y WITH DIAERESIS
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0100  LATIN CAPITAL LETTER A WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0101  LATIN SMALL LETTER A WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0102  LATIN CAPITAL LETTER A WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0103  LATIN SMALL LETTER A WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0104  LATIN CAPITAL LETTER A WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0105  LATIN SMALL LETTER A WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0106  LATIN CAPITAL LETTER C WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0107  LATIN SMALL LETTER C WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0108  LATIN CAPITAL LETTER C WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0109  LATIN SMALL LETTER C WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010A  LATIN CAPITAL LETTER C WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010B  LATIN SMALL LETTER C WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010C  LATIN CAPITAL LETTER C WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010D  LATIN SMALL LETTER C WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010E  LATIN CAPITAL LETTER D WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x010F  LATIN SMALL LETTER D WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0110  LATIN CAPITAL LETTER D WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0111  LATIN SMALL LETTER D WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0112  LATIN CAPITAL LETTER E WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0113  LATIN SMALL LETTER E WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0116  LATIN CAPITAL LETTER E WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0117  LATIN SMALL LETTER E WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0118  LATIN CAPITAL LETTER E WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0119  LATIN SMALL LETTER E WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011A  LATIN CAPITAL LETTER E WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011B  LATIN SMALL LETTER E WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011C  LATIN CAPITAL LETTER G WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011D  LATIN SMALL LETTER G WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011E  LATIN CAPITAL LETTER G WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x011F  LATIN SMALL LETTER G WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0120  LATIN CAPITAL LETTER G WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0121  LATIN SMALL LETTER G WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0122  LATIN CAPITAL LETTER G WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0123  LATIN SMALL LETTER G WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0124  LATIN CAPITAL LETTER H WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0125  LATIN SMALL LETTER H WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0126  LATIN CAPITAL LETTER H WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0127  LATIN SMALL LETTER H WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0128  LATIN CAPITAL LETTER I WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0129  LATIN SMALL LETTER I WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x012A  LATIN CAPITAL LETTER I WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x012B  LATIN SMALL LETTER I WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x012E  LATIN CAPITAL LETTER I WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x012F  LATIN SMALL LETTER I WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0130  LATIN CAPITAL LETTER I WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0131  LATIN SMALL LETTER DOTLESS I
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0134  LATIN CAPITAL LETTER J WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0135  LATIN SMALL LETTER J WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0136  LATIN CAPITAL LETTER K WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0137  LATIN SMALL LETTER K WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0138  LATIN SMALL LETTER KRA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0139  LATIN CAPITAL LETTER L WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x013A  LATIN SMALL LETTER L WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x013B  LATIN CAPITAL LETTER L WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x013C  LATIN SMALL LETTER L WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x013D  LATIN CAPITAL LETTER L WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x013E  LATIN SMALL LETTER L WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0141  LATIN CAPITAL LETTER L WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0142  LATIN SMALL LETTER L WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0143  LATIN CAPITAL LETTER N WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0144  LATIN SMALL LETTER N WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0145  LATIN CAPITAL LETTER N WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0146  LATIN SMALL LETTER N WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0147  LATIN CAPITAL LETTER N WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0148  LATIN SMALL LETTER N WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x014A  LATIN CAPITAL LETTER ENG
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x014B  LATIN SMALL LETTER ENG
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x014C  LATIN CAPITAL LETTER O WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x014D  LATIN SMALL LETTER O WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0150  LATIN CAPITAL LETTER O WITH DOUBLE ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0151  LATIN SMALL LETTER O WITH DOUBLE ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0154  LATIN CAPITAL LETTER R WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0155  LATIN SMALL LETTER R WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0156  LATIN CAPITAL LETTER R WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0157  LATIN SMALL LETTER R WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0158  LATIN CAPITAL LETTER R WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0159  LATIN SMALL LETTER R WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015A  LATIN CAPITAL LETTER S WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015B  LATIN SMALL LETTER S WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015C  LATIN CAPITAL LETTER S WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015D  LATIN SMALL LETTER S WITH CIRCUMFLEX
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015E  LATIN CAPITAL LETTER S WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x015F  LATIN SMALL LETTER S WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0160  LATIN CAPITAL LETTER S WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0161  LATIN SMALL LETTER S WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0162  LATIN CAPITAL LETTER T WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0163  LATIN SMALL LETTER T WITH CEDILLA
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0164  LATIN CAPITAL LETTER T WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0165  LATIN SMALL LETTER T WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0166  LATIN CAPITAL LETTER T WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0167  LATIN SMALL LETTER T WITH STROKE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0168  LATIN CAPITAL LETTER U WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0169  LATIN SMALL LETTER U WITH TILDE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016A  LATIN CAPITAL LETTER U WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016B  LATIN SMALL LETTER U WITH MACRON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016C  LATIN CAPITAL LETTER U WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016D  LATIN SMALL LETTER U WITH BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016E  LATIN CAPITAL LETTER U WITH RING ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x016F  LATIN SMALL LETTER U WITH RING ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0170  LATIN CAPITAL LETTER U WITH DOUBLE ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0171  LATIN SMALL LETTER U WITH DOUBLE ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0172  LATIN CAPITAL LETTER U WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0173  LATIN SMALL LETTER U WITH OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x0179  LATIN CAPITAL LETTER Z WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x017A  LATIN SMALL LETTER Z WITH ACUTE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x017B  LATIN CAPITAL LETTER Z WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x017C  LATIN SMALL LETTER Z WITH DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x017D  LATIN CAPITAL LETTER Z WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x017E  LATIN SMALL LETTER Z WITH CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x02C7  CARON
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x02D8  BREVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x02D9  DOT ABOVE
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x02DB  OGONEK
   _  @
  / \\ @
 ( � )@
  \\_/ @@
0x02DD  DOUBLE ACUTE ACCENT
   _  @
  / \\ @
 ( � )@
  \\_/ @@
`