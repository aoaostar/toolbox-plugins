export default `flf2a$ 1 1 11 -1 12 0

hex.flf by Karlton Wirsing based on
binary.flf (C) 1994 by Victor Parada (vparada@inf.utfsm.cl) 94/12/05

figlet 2.1 font, includes ISO Latin-1, excludes "-D" option chars.

Spaces are not shown as binary.  If this is required, change "$@" below
to "20 @".  Change to "@" to remove the hardspace between words.
Note that figlet always removes spaces when it moves words to a new line.

Try option "-m 0" to remove the space between letters (octets).

$@
21 @
22 @
23 @
24 @
25 @
26 @
27 @
28 @
29 @
2A @
2B @
2C @
2D @
2E @
2F @
30 @
31 @
32 @
33 @
34 @
35 @
36 @
37 @
38 @
39 @
3A @
3B @
3C @
3D @
3E @
3F @
40 @
41 @
42 @
43 @
44 @
45 @
46 @
47 @
48 @
49 @
4A @
4B @
4C @
4D @
4E @
4F @
50 @
51 @
52 @
53 @
54 @
55 @
56 @
57 @
58 @
59 @
5A @
5B @
5C @
5D @
5E @
5F @
60 @
61 @
62 @
63 @
64 @
65 @
66 @
67 @
68 @
69 @
6A @
6B @
6C @
6D @
6E @
6F @
70 @
71 @
72 @
73 @
74 @
75 @
76 @
77 @
78 @
79 @
7A @
7B @
7C @
7D @
7E @
@
@
@
@
@
@
@
127
7F @
128
80 @
129
81 @
130
82 @
131
83 @
132
84 @
133
85 @
134
86 @
135
87 @
136
88 @
137
89 @
138
8A @
139
8B @
140
8C @
141
8D @
142
8E @
143
8F @
144
90 @
145
91 @
146
92 @
147
93 @
148
94 @
149
95 @
150
96 @
151
97 @
152
98 @
153
99 @
154
9A @
155
9B @
156
9C @
157
9D @
158
9E @
159
9F @
160
A0 @
161
A1 @
162
A2 @
163
A3 @
164
A4 @
165
A5 @
166
A6 @
167
A7 @
168
A8 @
169
A9 @
170
AA @
171
AB @
172
AC @
173
AD @
174
AE @
175
AF @
176
B0 @
177
B1 @
178
B2 @
179
B3 @
180
B4 @
181
B5 @
182
B6 @
183
B7 @
184
B8 @
185
B9 @
186
BA @
187
BB @
188
BC @
189
BD @
190
BE @
191
BF @
192
C0 @
193
C1 @
194
C2 @
195
C3 @
196
C4 @
197
C5 @
198
C6 @
199
C7 @
200
C8 @
201
C9 @
202
CA @
203
CB @
204
CC @
205
CD @
206
CE @
207
CF @
208
D0 @
209
D1 @
210
D2 @
211
D3 @
212
D4 @
213
D5 @
214
D6 @
215
D7 @
216
D8 @
217
D9 @
218
DA @
219
DB @
220
DC @
221
DD @
222
DE @
223
DF @
224
E0 @
225
E1 @
226
E2 @
227
E3 @
228
E4 @
229
E5 @
230
E6 @
231
E7 @
232
E8 @
233
E9 @
234
EA @
235
EB @
236
EC @
237
ED @
238
EE @
239
EF @
240
F0 @
241
F1 @
242
F2 @
243
F3 @
244
F4 @
245
F5 @
246
F6 @
247
F7 @
248
F8 @
249
F9 @
250
FA @
251
FB @
252
FC @
253
FD @
254
FE @
255
FF @
`