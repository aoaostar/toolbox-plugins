export default `flf2a$ 10 9 21 -1 22

                  Nekochan thin font by LESTER
                 ==============================


-> Conversion to FigLet font by MEPH. (Part of ASCII Editor Service Pack I)
   (http://studenten.freepage.de/meph/ascii/ascii/editor/_index.htm)
-> Defined: ASCII code alphanumeric


     .-~~-.
    (_^..^_)
Lester||||AMC - Anthony Cucchiara
*Mythos Online : Internet Magazine of Lovecraftian Horror - Dead Alice*
http://www.fortunecity.com/victorian/redlion/157/deadal.htm
*Visit my web page ANSI/ASCII/Fonts*
http://members.aol.com/lester5374/

---

Font modified June 17, 2007 by patorjk 
This was to widen the space character.
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@
    $@@
SSSSS @
S SSS @
S  SS @
S;;;S @
S%%%S @
SSSSS @
.sSs. @
S%%%S @
\`:;:' @
      @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
      @
      @
      @
      @
      @
      @
.sSs. @
S%%%S @
\`"":5 @
  ;:' @@
        @
        @
        @
        @
sssssss @
        @
        @
        @
        @
        @@
      @
      @
      @
      @
      @
      @
.sSs. @
S%%%S @
\`:;:' @
      @@
@
@
@
@
@
@
@
@
@
@@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS\\SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
\`:;SSsSS;:' @
            @@
SsSSs.    @
  SSSSs   @
  S SSS   @
  S  SS   @
  S..SS   @
  S:::S   @
  S;;;S   @
  S%%%S   @
SsSSSSSsS @
          @@
.sSSSSs.    @
\`SSSS SSSs. @
      SSSSS @
.sSSSsSSSS' @
S..SS       @
S:::S SSSs. @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
.sSSSSSSs.  @
\`SSSS SSSSs @
      S SSS @
  .sS S  SS @
 SSSSsS..SS @
  \`:; S:::S @
      S;;;S @
.SSSS S%%%S @
\`:;SSsSSSSS @
            @@
.sSSS s.    @
SSSSS SSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SSsSSSSS @
      SSSSS @
      SSSSS @
      SSSSS @
      SSSSS @
            @@
SSSSSSSSSs. @
SSSSS SSSS' @
S SSS       @
SSSSSsSSSs. @
      SSSSS @
.sSSS SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
\`:;SSsSS;:' @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSS' @
S  SS       @
S...SsSSSa. @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
\`:;SSsSS;:' @
            @@
SSSSSSSSSs. @
SSSSSSSSSSS @
     S SSS  @
    S  SS   @
   S..SS    @
  S:::S     @
 S;;;S      @
S%%%S       @
SSSSS       @
            @@
.sSSSSs.    @
SSSSS SSSs. @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSs' @
s:::S SSSSs @
S;;;S SSSSS @
S%%%S SSSSS @
\`:;SSsSS;:' @
            @@
.sSSSSs.    @
SSSSS SSSs. @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSSS @
      SSSSS @
.sSSS SSSSS @
S%%%S SSSSS @
\`:;SSsSS;:' @
            @@
      @
.sSs. @
S%%%S @
\`:;:' @
      @
      @
.sSs. @
S%%%S @
\`:;:' @
      @@
      @
.sSs. @
S%%%S @
\`:;:' @
      @
      @
.sSs. @
S%%%S @
\`"":5 @
  ;:' @@
            @
            @
            @
 .sS        @
SSSSsssssss @
 \`:;        @
            @
            @
            @
            @@
@
@
@
@
@
@
@
@
@
@@
            @
            @
            @
       Ss.  @
sssssssSSSS @
       ;:'  @
            @
            @
            @
            @@
.sSSSSs.    @
S SSSSSSSs. @
\`..SS SSSSS @
      SSSSS @
   .ssSSSSS @
   SSSSS;:' @
   .sSs.    @
   S%%%S    @
   \`:;:'    @
            @@
@
@
@
@
@
@
@
@
@
@@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SSsSSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSS' @
S..SSsSSSa. @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSS' @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSS' @
S..SS       @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSS' @
SSSSSsS;:'  @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSS' @
S  SS       @
S..SSsss    @
S:::SSSS    @
S;;;S       @
S%%%S SSSSS @
SSSSSsSS;:' @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSS' @
S  SS       @
S..SSsss    @
S:::SSSS    @
S;;;S       @
S%%%S       @
SSSSS       @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSS' @
S..SS       @
S:::S\`sSSs. @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
.sSSS SSSSS @
SSSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
S..SSsSSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
SSSSS @
SSSSS @
S SSS @
S  SS @
S..SS @
S:::S @
S;;;S @
S%%%S @
SSSSS @
      @@
      SSSSS @
      SSSSS @
      S SSS @
      S  SS @
      S..SS @
      S:::S @
      S;;;S @
SSSSS S%%%S @
\`:;SSsSSSSS @
            @@
.sSSS  SSSSS  @
SSSSS  SSSSS  @
S SSS SSSSS   @
S  SS SSSSS   @
S..SSsSSSSS   @
S:::S SSSSS   @
S;;;S  SSSSS  @
S%%%S  SSSSS  @
SSSSS   SSSSS @
              @@
SSSSS       @
SSSSS       @
S SSS       @
S  SS       @
S..SS       @
S:::S       @
S;;;S       @
S%%%S SSSSS @
SSSSSsSS;:' @
            @@
.sSSSsSS SSsSSSSS @
SSSSS  SSS  SSSSS @
S SSS   S   SSSSS @
S  SS       SSSSS @
S..SS       SSSSS @
S:::S       SSSSS @
S;;;S       SSSSS @
S%%%S       SSSSS @
SSSSS       SSSSS @
                  @@
.sSSSs.  SSSSS @
SSSSS SS SSSSS @
S SSS  \`sSSSSS @
S  SS    SSSSS @
S..SS    SSSSS @
S:::S    SSSSS @
S;;;S    SSSSS @
S%%%S    SSSSS @
SSSSS    SSSSS @
               @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS SSSSS @
S:::SsSSSSS @
S;;;S       @
S%%%S       @
SSSSS       @
            @@
.sSSSSs.     @
SSSSSSSSSs.  @
S SSS SSSSS  @
S  SS SSSSS  @
S..SS SSSSS  @
S:::S SSSSS  @
S;;;S SSSSS  @
S%%%S SSSSS  @
SSSSSsSSSSss @
             @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSSS @
S  SS SSSS' @
S..SSsSSSa. @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
.sSSSSs.    @
SSSSSSSSSs. @
S SSS SSSS' @
S  SS       @
\`SSSSsSSSa. @
.sSSS SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
   .sSSSSSSSSs.   @
.sSSSSSSSSSSSSSs. @
SSSSS S SSS SSSSS @
SSSSS S  SS SSSSS @
\`:S:' S..SS \`:S:' @
      S:::S       @
      S;;;S       @
      S%%%S       @
      SSSSS       @
                  @@
.sSSS s.    @
SSSSS SSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
.sSSS s.    @
SSSSS SSSs. @
S SSS SSSSS @
S  SS SSSSS @
S..SS SSSSS @
 S::S SSSS  @
  S;S SSS   @
   SS SS    @
    SsS     @
            @@
.sSSS       s.    @
SSSSS       SSSs. @
S SSS       SSSSS @
S  SS       SSSSS @
S..SS       SSSSS @
S:::S       SSSSS @
S;;;S   S   SSSSS @
S%%%S  SSS  SSSSS @
SSSSSsSS SSsSSSSS @
                  @@
.sSSS SSSSS @
SSSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSs' @
s:::S SSSSs @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
.sSSS SSSSS @
SSSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSS' @
   S:::S    @
   S;;;S    @
   S%%%S    @
   SSSSS    @
            @@
SSSSSSSSSs. @
SSSSSSSSSSS @
     S SSS  @
    S  SS   @
   S..SS    @
  S:::S     @
 S;;;S      @
S%%%SSSSSSS @
SSSSSSSSSSS @
            @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSSS @
S..SSsSSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSS' @
S..SSsSSSa. @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSS' @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSS' @
S..SS       @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSS' @
SSSSSsS;:'  @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSS' @
S..SS       @
S:::SSSS    @
S;;;S       @
S%%%S SSSSS @
SSSSSsSS;:' @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSS' @
S..SS       @
S:::SSSS    @
S;;;S       @
S%%%S       @
SSSSS       @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSS' @
S..SS       @
S:::S\`sSSs. @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
            @
.sSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
S..SSsSSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
      @
SSSSS @
S SSS @
S  SS @
S..SS @
S:::S @
S;;;S @
S%%%S @
SSSSS @
      @@
            @
      SSSSS @
      S SSS @
      S  SS @
      S..SS @
      S:::S @
      S;;;S @
SSSSS S%%%S @
\`:;SSsSSSSS @
            @@
              @
.sSSS  SSSSS  @
S SSS SSSSS   @
S  SS SSSSS   @
S..SSsSSSSS   @
S:::S SSSSS   @
S;;;S  SSSSS  @
S%%%S  SSSSS  @
SSSSS   SSSSS @
              @@
            @
SSSSS       @
S SSS       @
S  SS       @
S..SS       @
S:::S       @
S;;;S       @
S%%%S SSSSS @
SSSSSsSS;:' @
            @@
                  @
.sSSSsSS SSsSSSSS @
S SSS  SSS  SSSSS @
S  SS   S   SSSSS @
S..SS       SSSSS @
S:::S       SSSSS @
S;;;S       SSSSS @
S%%%S       SSSSS @
SSSSS       SSSSS @
                  @@
               @
.sSSSs.  SSSSS @
S SSS SS SSSSS @
S  SS  \`sSSSSS @
S..SS    SSSSS @
S:::S    SSSSS @
S;;;S    SSSSS @
S%%%S    SSSSS @
SSSSS    SSSSS @
               @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
            @
.sSSSSs.    @
S SSSSSSSs. @
S  SS SSSSS @
S..SS SSSSS @
S:::SsSSSSS @
S;;;S       @
S%%%S       @
SSSSS       @
            @@
             @
.sSSSSs.     @
S SSSSSSSs.  @
S  SS SSSSS  @
S..SS SSSSS  @
S:::S SSSSS  @
S;;;S SSSSS  @
S%%%S SSSSS  @
SSSSSsSSSSss @
             @@
            @
.sSSSSSSSs. @
S SSS SSSSS @
S  SS SSSS' @
S..SSsSSSa. @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
            @
.sSSSSSSSs. @
S SSS SSSS' @
S  SS       @
\`SSSSsSSSa. @
.sSSS SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
                  @
.sSSSSSSSSSSSSSs. @
SSSSS S SSS SSSSS @
SSSSS S  SS SSSSS @
\`:S:' S..SS \`:S:' @
      S:::S       @
      S;;;S       @
      S%%%S       @
      SSSSS       @
                  @@
            @
.sSSS s.    @
S SSS SSSs. @
S  SS SSSSS @
S..SS SSSSS @
S:::S SSSSS @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSSsSSSSS @
            @@
            @
.sSSS s.    @
S SSS SSSs. @
S  SS SSSSS @
S..SS SSSSS @
 S::S SSSS  @
  S;S SSS   @
   SS SS    @
    SsS     @
            @@
                  @
.sSSS       s.    @
S SSS       SSSs. @
S  SS       SSSSS @
S..SS       SSSSS @
S:::S       SSSSS @
S;;;S   S   SSSSS @
S%%%S  SSS  SSSSS @
SSSSSsSS SSsSSSSS @
                  @@
            @
.sSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSs' @
s:::S SSSSs @
S;;;S SSSSS @
S%%%S SSSSS @
SSSSS SSSSS @
            @@
            @
.sSSS SSSSS @
S SSS SSSSS @
S  SS SSSSS @
\`..SSsSSSS' @
   S:::S    @
   S;;;S    @
   S%%%S    @
   SSSSS    @
            @@
            @
SSSSSSSSSs. @
SSSSSS SSS' @
    S  SS   @
   S..SS    @
  S:::S     @
 S;;;S      @
S%%%SSSSSSS @
SSSSSSSSSSS @
            @@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
@
@
@
@
@
@
@
@
@
@@
`