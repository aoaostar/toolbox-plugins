<?php

namespace plugin\aoaostar_com\str_count;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return msg("ok","success");
    }
}