<?php

namespace plugin\aoaostar_com\markdown;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return success();
    }
}