<?php

namespace plugin\aoaostar_com\image2base64;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return msg("ok","success");
    }
}