<?php

namespace plugin\aoaostar_com\piano;

use plugin\Drive;

class App implements Drive
{

    public function Index()
    {
        return success();
    }
}