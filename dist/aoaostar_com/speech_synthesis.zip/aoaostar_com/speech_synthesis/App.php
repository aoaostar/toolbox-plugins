<?php

namespace plugin\aoaostar_com\speech_synthesis;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return msg("ok","success");
    }
}