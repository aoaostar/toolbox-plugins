<?php

namespace plugin\aoaostar_com\gq_avatar;

use plugin\Drive;

class App implements Drive
{
    public function Index()
    {
    }
}