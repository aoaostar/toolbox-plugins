<?php

namespace plugin\aoaostar_com\aria2;

use plugin\Drive;

class App implements Drive
{

    public function Index()
    {
        return success();
    }
}