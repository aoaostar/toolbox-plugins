<?php


interface plugin
{
    public function main($filepath): string;
}