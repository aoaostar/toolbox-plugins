<?php


namespace plugin\aoaostar_com\image_url;

interface Plugin
{
    public function main($filepath): string;
}