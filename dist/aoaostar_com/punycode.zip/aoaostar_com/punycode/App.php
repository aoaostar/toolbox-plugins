<?php

namespace plugin\aoaostar_com\punycode;

use plugin\Drive;

class App implements Drive
{
    public function Index()
    {
        // TODO: Implement Index() method.
    }
}