<?php

namespace plugin\aoaostar_com\code_js;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return msg("ok","success");
    }
}