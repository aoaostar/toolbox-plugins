<?php

namespace plugin\aoaostar_com\urlencode;

use plugin\Drive;

class App implements Drive
{


    public function Index()
    {
        return success();
    }
}